import {samplingGLSL,tintSamplingGLSL,brightnessGLSL} from '../../src/map/restored-map-suite/heat-field/sampling.ts';
import {createHash} from 'node:crypto';
// Deliberately version-bound: reject an unknown renderer instead of silently missing buildings.
export function patchMapLibre(source){
 const hash=createHash('sha256').update(source).digest('hex');
 if(hash!=='57cd72f2ceb1d724e8f9153aff0726844728e2eeaa8ced2f040b2c44b038a138')throw Error('Unsupported MapLibre source fingerprint: '+hash);
 function replace(a,b){if(source.split(a).length!==2)throw Error('MapLibre adapter anchor ambiguous: '+a.slice(0,70));source=source.replace(a,b);}
 function shader(name,fn){const re=new RegExp('var '+name+" = ('[^\\n]*');");const m=source.match(re);if(!m)throw Error(name);const value=Function('return '+m[1])();replace(m[0],'var '+name+' = '+JSON.stringify(fn(value))+';');}
 shader('fillExtrusionVert',s=>'uniform highp float u_mapBuildingGrowth;uniform vec4 u_heatTile;out highp vec2 v_heatUV;out highp vec3 v_heatNormal;out highp float v_heatHeight;'+s.replace('base=max(0.0,base)', 'base=max(0.0,base)*u_mapBuildingGrowth').replace('height=max(0.0,height)', 'height=max(0.0,height)*u_mapBuildingGrowth').replace('uniform vec3 u_lightcolor;','uniform highp vec3 u_lightcolor;').replace('vec2 posInTile=a_pos+u_fill_translate;','vec2 posInTile=a_pos+u_fill_translate;v_heatUV=u_heatTile.xy+posInTile*u_heatTile.zw;').replace('v_color*=u_opacity;','v_heatNormal=normalize(vec3(normal.x,normal.z,normal.y));v_heatHeight=t;v_color*=u_opacity;'));
 shader('fillExtrusionFrag',s=>'uniform float u_heatBlur;uniform float u_brightness;uniform sampler2D u_heatSampler;uniform float u_heatEnabled;uniform float u_heatStrength;uniform highp vec3 u_lightcolor;uniform highp vec2 u_heatSize;in highp vec2 v_heatUV;in highp vec3 v_heatNormal;in highp float v_heatHeight;uniform highp vec3 u_tintLight;uniform highp vec3 u_tintLightColor;uniform highp vec4 u_tintShade;'+samplingGLSL+tintSamplingGLSL.replaceAll('texture2D(', 'texture(')+brightnessGLSL+s.replace('fragColor=v_color;','fragColor=v_color;vec2 sampleUV=heatSampleUV(v_heatUV,u_heatSize);if(u_heatEnabled>0.5 && all(greaterThanEqual(sampleUV,vec2(0.0))) && all(lessThan(sampleUV,vec2(1.0)))){vec4 h=heatTintSample(u_heatSampler,v_heatUV,u_heatSize,u_heatBlur);if(h.a>0.5){vec3 n=normalize(v_heatNormal);float roof=step(0.5,n.y),litAmount=max(0.0,dot(n,u_tintLight));float shade=1.0-u_tintShade.x*(1.0-litAmount)*(1.0-roof*0.75);shade*=1.0-u_tintShade.z*(1.0-u_tintShade.w)*(1.0-v_heatHeight)*0.18;shade*=mix(1.0,u_tintShade.y,roof);float neutral=dot(mix(vec3(1.0),u_tintLightColor,litAmount*0.3),vec3(0.2126,0.7152,0.0722));vec3 lit=heatBrightness(h.rgb,u_brightness)*neutral*shade;fragColor.rgb=mix(v_color.rgb,lit*v_color.a,u_heatStrength);}}'));
 replace('const fillExtrusionUniforms = (context, locations) => ({',`const fillExtrusionUniforms = (context, locations) => ({
 'u_mapBuildingGrowth':new symbol_layout.Uniform1f(context,locations.u_mapBuildingGrowth),
 'u_tintLight':new symbol_layout.Uniform3f(context,locations.u_tintLight),
 'u_tintLightColor':new symbol_layout.Uniform3f(context,locations.u_tintLightColor),
 'u_tintShade':new symbol_layout.Uniform4f(context,locations.u_tintShade),
 'u_heatBlur':new symbol_layout.Uniform1f(context,locations.u_heatBlur),
 'u_brightness':new symbol_layout.Uniform1f(context,locations.u_brightness),
 'u_heatSize':new symbol_layout.Uniform2f(context,locations.u_heatSize),
 'u_heatTile':new symbol_layout.Uniform4f(context,locations.u_heatTile),
 'u_heatSampler':new symbol_layout.Uniform1i(context,locations.u_heatSampler),
 'u_heatEnabled':new symbol_layout.Uniform1f(context,locations.u_heatEnabled),
 'u_heatStrength':new symbol_layout.Uniform1f(context,locations.u_heatStrength),`);
 replace('fillExtrusionUniformValues(painter, shouldUseVerticalGradient, opacity, translate);',`fillExtrusionUniformValues(painter, shouldUseVerticalGradient, opacity, translate);
        if(!image)Object.assign(uniformValues,{u_mapBuildingGrowth:painter.style.map.__mapBuildingGrowth?.(layer.id)??1,u_tintLight:[0,1,0],u_tintLightColor:[1,1,1],u_tintShade:[0,1,0,1],u_heatBlur:0,u_brightness:1,u_heatSize:[1,1],u_heatTile:[0,0,0,0],u_heatSampler:7,u_heatEnabled:0,u_heatStrength:0},painter.style.map.__heatTint?.(layer.id,coord,context));`);
 replace('exports$1.Map = Map$1;',"Map$1.prototype.__mapBuildingGrowthAdapter=1;\nMap$1.prototype.__heatAdapterVersion='grid-heat-maplibre-5.24.0-v1';\nexports$1.Map = Map$1;");
 return source;
}
