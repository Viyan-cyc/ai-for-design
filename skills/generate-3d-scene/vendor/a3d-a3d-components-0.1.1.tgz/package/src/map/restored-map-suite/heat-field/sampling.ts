/** Same 1e-4-cell normalization in CPU cellIndex and both fragment shaders. */
export const samplingGLSL = `
vec2 heatSampleUV(vec2 uv,vec2 size){
 vec2 cell=uv*size;
 vec2 nearest=floor(cell+vec2(0.5));
 cell=mix(cell,nearest,lessThanEqual(abs(cell-nearest),vec2(0.0001)));
 return (floor(cell)+vec2(0.5))/size;
}
`;

export const brightnessGLSL=`
vec3 heatBrightness(vec3 color,float amount){return amount<=1.0?color*amount:mix(color,vec3(1.0),(amount-1.0)*.5);}
`;

/** Explicit sRGB transfer after brightness; feed linear RGB into Three PBR. */
export const heatColorGLSL=`
vec3 heatSRGBToLinear(vec3 color){
 return mix(pow((color+vec3(0.055))/1.055,vec3(2.4)),color/12.92,lessThanEqual(color,vec3(0.04045)));
}
`;

/** Reference v1.7 transition: zero = cells, 0..1 = smooth boundary, >=2 = linear wide field.
 * Keep the owning-cell validity mask: interpolation must not fill missing business cells.
 */
export const tintSamplingGLSL = `
vec4 heatTintSample(sampler2D field,vec2 uv,vec2 size,float blur){
 vec2 ownUV=heatSampleUV(uv,size);
 if(any(lessThan(ownUV,vec2(0.0)))||any(greaterThanEqual(ownUV,vec2(1.0))))return vec4(0.0);
 vec4 own=texture2D(field,ownUV);
 if(own.a<0.5||blur<=0.0)return own;
 vec2 q=uv*size-0.5,cell=floor(q),f=fract(q);
 vec2 halfWidth=vec2(min(blur,1.0)*0.5);
 vec2 narrow=smoothstep(vec2(0.5)-halfWidth,vec2(0.5)+halfWidth,f);
 vec2 t=blur>=2.0?f:mix(narrow,f,smoothstep(1.0,2.0,blur));
 vec2 lo=(clamp(cell,vec2(0.0),size-1.0)+0.5)/size;
 vec2 hi=(clamp(cell+1.0,vec2(0.0),size-1.0)+0.5)/size;
 vec4 a=texture2D(field,lo),b=texture2D(field,vec2(hi.x,lo.y));
 vec4 c=texture2D(field,vec2(lo.x,hi.y)),d=texture2D(field,hi);
 a.rgb*=a.a;b.rgb*=b.a;c.rgb*=c.a;d.rgb*=d.a;
 vec4 color=mix(mix(a,b,t.x),mix(c,d,t.x),t.y);
 return vec4(color.rgb/max(color.a,0.000001),own.a);
}
`;
