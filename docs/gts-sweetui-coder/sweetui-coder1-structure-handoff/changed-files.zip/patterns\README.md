# 组合模式

- [工作台](workbench/README.md)：导航、页签、会话、对话、分析与关联证据。AI 工作台与资源查询共用同一骨架，通过 mode 切换。
- [查询详情](search-detail/)：条件筛选、分页与详情抽屉；api 文件复制到工程 src/api。
- [表单弹窗](form-dialog/)：表单弹窗。
- [内容网格](content-grid/)：内容网格。

按需选一个模式，初始化使用 scripts/preview/page.vue，不全量读取。
