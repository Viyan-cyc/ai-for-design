export const resources = [
  { id: 'R-001', name: '应用服务器-01', region: '北京二区', ip: '10.24.1.11', status: '运行中', owner: '基础设施组', updated: '2026-10-28 09:42' },
  { id: 'R-002', name: '存储节点-02', region: '广州一区', ip: '10.24.2.12', status: '运行中', owner: '平台工程组', updated: '2026-10-28 09:42' },
  { id: 'R-003', name: '边缘网关-03', region: '上海一区', ip: '10.24.3.13', status: '运行中', owner: '网络运维组', updated: '2026-10-28 09:42' },
  { id: 'R-004', name: '核心交换机-04', region: '北京二区', ip: '10.24.0.14', status: '运行中', owner: '基础设施组', updated: '2026-10-28 09:42' },
  { id: 'R-005', name: '应用服务器-05', region: '广州一区', ip: '10.24.1.15', status: '运行中', owner: '平台工程组', updated: '2026-10-28 09:42' },
  { id: 'R-006', name: '存储节点-06', region: '上海一区', ip: '10.24.2.16', status: '需关注', owner: '网络运维组', updated: '2026-10-28 09:42' },
  { id: 'R-007', name: '边缘网关-07', region: '北京二区', ip: '10.24.3.17', status: '运行中', owner: '基础设施组', updated: '2026-10-28 09:42' },
  { id: 'R-008', name: '核心交换机-08', region: '广州一区', ip: '10.24.0.18', status: '运行中', owner: '平台工程组', updated: '2026-10-28 09:42' },
  { id: 'R-009', name: '应用服务器-09', region: '上海一区', ip: '10.24.1.19', status: '运行中', owner: '网络运维组', updated: '2026-10-28 09:42' },
  { id: 'R-010', name: '存储节点-10', region: '北京二区', ip: '10.24.2.20', status: '运行中', owner: '基础设施组', updated: '2026-10-28 09:42' },
  { id: 'R-011', name: '边缘网关-11', region: '广州一区', ip: '10.24.3.21', status: '运行中', owner: '平台工程组', updated: '2026-10-28 09:42' },
  { id: 'R-012', name: '核心交换机-12', region: '上海一区', ip: '10.24.0.22', status: '需关注', owner: '网络运维组', updated: '2026-10-28 09:42' },
  { id: 'R-013', name: '应用服务器-13', region: '北京二区', ip: '10.24.1.23', status: '运行中', owner: '基础设施组', updated: '2026-10-28 09:42' },
  { id: 'R-014', name: '存储节点-14', region: '广州一区', ip: '10.24.2.24', status: '运行中', owner: '平台工程组', updated: '2026-10-28 09:42' },
  { id: 'R-015', name: '边缘网关-15', region: '上海一区', ip: '10.24.3.25', status: '运行中', owner: '网络运维组', updated: '2026-10-28 09:42' },
  { id: 'R-016', name: '核心交换机-16', region: '北京二区', ip: '10.24.0.26', status: '运行中', owner: '基础设施组', updated: '2026-10-28 09:42' },
  { id: 'R-017', name: '应用服务器-17', region: '广州一区', ip: '10.24.1.27', status: '运行中', owner: '平台工程组', updated: '2026-10-28 09:42' },
  { id: 'R-018', name: '存储节点-18', region: '上海一区', ip: '10.24.2.28', status: '需关注', owner: '网络运维组', updated: '2026-10-28 09:42' },
  { id: 'R-019', name: '边缘网关-19', region: '北京二区', ip: '10.24.3.29', status: '运行中', owner: '基础设施组', updated: '2026-10-28 09:42' },
  { id: 'R-020', name: '核心交换机-20', region: '广州一区', ip: '10.24.0.30', status: '运行中', owner: '平台工程组', updated: '2026-10-28 09:42' },
  { id: 'R-021', name: '应用服务器-21', region: '上海一区', ip: '10.24.1.31', status: '运行中', owner: '网络运维组', updated: '2026-10-28 09:42' },
  { id: 'R-022', name: '存储节点-22', region: '北京二区', ip: '10.24.2.32', status: '运行中', owner: '基础设施组', updated: '2026-10-28 09:42' },
  { id: 'R-023', name: '边缘网关-23', region: '广州一区', ip: '10.24.3.33', status: '运行中', owner: '平台工程组', updated: '2026-10-28 09:42' },
  { id: 'R-024', name: '核心交换机-24', region: '上海一区', ip: '10.24.0.34', status: '需关注', owner: '网络运维组', updated: '2026-10-28 09:42' }
]

export const sessions = [
  { id: 'mail', title: '邮件应用发送失败排查', time: '今天 10:35', status: '已完成' },
  { id: 'network', title: '核心交换机链路诊断', time: '今天 09:42', status: '待处理' },
  { id: 'storage', title: '存储容量趋势分析', time: '昨天 16:20', status: '已完成' }
]

export const evidence = [
  { id: 'a1', name: '核心交换机电源异常', device: 'ZJINT-CORE-SW-01', level: '紧急', time: '10:23:15' },
  { id: 'a2', name: 'BGP 邻居会话中断', device: 'ZJINT-CORE-SW-01', level: '重要', time: '10:24:03' },
  { id: 'a3', name: '邮件服务连接超时', device: 'MAIL-APP-02', level: '重要', time: '10:25:42' }
]

export const report = {
  question: '银行客户反馈邮件应用发送失败，同时出现大量告警，请帮我排查关联关系和根因。',
  summary: '已完成邮件应用与底层网络的关联分析，发现一条需要优先关注的故障链路。',
  steps: [
    { id: 'query', title: '全网告警查询', time: '500ms', text: '查询 10:20:15 — 10:35:42 的全网告警，定位业务异常时间窗口。', action: '查看关联告警' },
    { id: 'clean', title: '告警清洗与关联', time: '300ms', text: '合并重复事件，关联交换机、网络邻居与邮件应用的依赖关系。', action: '查看清洗结果' },
    { id: 'root', title: '识别潜在根因', time: '600ms', text: '核心交换机电源异常先于网络会话中断，建议优先核查设备供电状态。', action: '查看分析结论' }
  ],
  conclusion: '核心交换机电源模块异常，可能引发 BGP 会话中断，继而影响邮件服务连接。',
  description: '当前为示例分析，不代表真实诊断。实际处置前应核对设备日志、供电告警与业务恢复情况。',
  suggestions: ['检查电源模块与供电链路', '核对 BGP 邻居恢复状态', '验证邮件业务连通性']
}
