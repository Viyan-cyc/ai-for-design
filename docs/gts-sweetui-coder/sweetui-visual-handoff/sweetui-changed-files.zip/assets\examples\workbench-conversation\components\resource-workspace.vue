<script setup>
import { ref, computed, onMounted } from 'vue'
import { SweetButton, SweetInput, SweetSelect, SweetOption, SweetTable, SweetTableColumn, SweetPagination, SweetDrawer, SweetDescriptions, SweetDescriptionsItem, SweetIcon, SweetAlert, SweetTag } from '@hw-seq/sweet-ui-base'
import { getResources } from '../api/foundation.js'
const records = ref([])
const query = ref('')
const status = ref('all')
const applied = ref({ query: '', status: 'all' })
const page = ref(1)
const detail = ref(null)
const loading = ref(false)
const error = ref('')
const filtered = computed(() => records.value.filter(r =>
  (applied.value.status === 'all' || r.status === applied.value.status) &&
  `${r.name} ${r.ip}`.toLowerCase().includes(applied.value.query.toLowerCase())
))
const paged = computed(() => filtered.value.slice((page.value - 1) * 8, page.value * 8))
const stats = computed(() => [
  { id: 'total', label: '纳管资源', value: records.value.length, unit: '台', icon: 'sweetui-icon-dashboard-l', tone: 'brand' },
  { id: 'healthy', label: '运行正常', value: records.value.filter(r => r.status === '运行中').length, unit: '台', icon: 'sweetui-icon-success-l', tone: 'success' },
  { id: 'attention', label: '需要关注', value: records.value.filter(r => r.status === '需关注').length, unit: '台', icon: 'sweetui-icon-warning-l', tone: 'alert' }
])
async function load() {
  loading.value = true
  try { records.value = await getResources(); error.value = '' }
  catch { error.value = '资源加载失败，请重试' }
  finally { loading.value = false }
}
onMounted(load)
function search() { applied.value = { query: query.value, status: status.value }; page.value = 1 }
function reset() { query.value = ''; status.value = 'all'; search() }
const statusOptions = [
  { value: 'all', label: '全部状态' },
  { value: '运行中', label: '运行中' },
  { value: '需关注', label: '需关注' }
]
</script>
<template>
  <section class="resources">
    <header class="page-heading">
      <div>
        <div class="breadcrumb">基础设施 <SweetIcon icon-class="sweetui-icon-arrow-right" :size="12" /> 资源管理</div>
        <h1>资源总览</h1>
        <p>统一查看资源运行状态，快速定位需要关注的设备。</p>
      </div>
      <SweetButton :loading="loading" @click="load">
        <SweetIcon icon-class="sweetui-icon-refresh-l" :size="14" />
        刷新数据
      </SweetButton>
    </header>
    <div class="summary-strip">
      <div v-for="item in stats" :key="item.id" class="stat">
        <span class="stat-icon" :class="item.tone">
          <SweetIcon :icon-class="item.icon" :size="20" />
        </span>
        <div>
          <span class="stat-label">{{ item.label }}</span>
          <div><strong>{{ item.value }}</strong><span class="unit">{{ item.unit }}</span></div>
        </div>
      </div>
      <span class="data-source">演示数据<br />更新于 09:42</span>
    </div>
    <div class="table-card">
      <div class="table-title">
        <h2>资源列表</h2>
        <span>共 {{ records.length }} 台资源</span>
      </div>
      <div class="filters">
        <label for="res-query">关键词</label>
        <SweetInput id="res-query" v-model="query" clearable placeholder="资源名称 / IP 地址" class="query" size="small" @keyup.enter="search" />
        <label for="res-status">运行状态</label>
        <SweetSelect id="res-status" v-model="status" class="status-select" size="small">
          <SweetOption v-for="opt in statusOptions" :key="opt.value" :label="opt.label" :value="opt.value" />
        </SweetSelect>
        <SweetButton type="primary" size="small" @click="search">
          <SweetIcon icon-class="sweetui-icon-search-l" :size="14" />
          查询
        </SweetButton>
        <SweetButton size="small" @click="reset">重置</SweetButton>
      </div>
      <SweetAlert v-if="error" :title="error" type="error" :closable="false" show-icon>
        <SweetButton size="small" @click="load">重试</SweetButton>
      </SweetAlert>
      <SweetTable v-else stripe :data="paged" size="small" empty-text="暂无匹配资源">
        <SweetTableColumn prop="name" label="资源名称" min-width="220">
          <template #default="scope">
            <button type="button" class="resource-link" @click="detail = scope.row">
              <SweetIcon icon-class="sweetui-icon-dashboard-l" :size="16" />
              {{ scope.row.name }}
            </button>
          </template>
        </SweetTableColumn>
        <SweetTableColumn prop="ip" label="IP 地址" min-width="150" />
        <SweetTableColumn prop="region" label="所属区域" min-width="120" />
        <SweetTableColumn prop="status" label="运行状态" min-width="120">
          <template #default="scope">
            <span class="resource-status" :class="{ attention: scope.row.status === '需关注' }">
              <i />{{ scope.row.status }}
            </span>
          </template>
        </SweetTableColumn>
        <SweetTableColumn prop="owner" label="负责团队" min-width="150" />
        <SweetTableColumn prop="updated" label="最近更新" min-width="180" />
        <SweetTableColumn label="操作" width="85">
          <template #default="scope">
            <SweetButton link type="primary" size="small" @click="detail = scope.row">详情</SweetButton>
          </template>
        </SweetTableColumn>
      </SweetTable>
      <footer class="table-foot">
        <span>共 {{ filtered.length }} 条 · 每页 8 条</span>
        <SweetPagination v-model:current-page="page" :page-size="8" :total="filtered.length" layout="prev, pager, next" background small :pager-count="5" />
      </footer>
    </div>
    <p class="bottom-note">同一工作台骨架 · 不同业务装配 · 该示例不显示对话输入组件</p>
    <SweetDrawer :model-value="!!detail" title="资源详情" size="420px" @update:model-value="detail = null">
      <template v-if="detail">
        <SweetDescriptions :column="1" border size="small">
          <SweetDescriptionsItem v-for="field in [
            { key: 'id', label: '资源 ID' },
            { key: 'name', label: '名称' },
            { key: 'ip', label: 'IP 地址' },
            { key: 'region', label: '区域' },
            { key: 'status', label: '状态' },
            { key: 'owner', label: '负责团队' }
          ]" :key="field.key" :label="field.label">
            <SweetTag v-if="field.key === 'status'" :type="detail[field.key] === '需关注' ? 'warning' : 'success'" size="small">
              {{ detail[field.key] }}
            </SweetTag>
            <template v-else>{{ detail[field.key] }}</template>
          </SweetDescriptionsItem>
        </SweetDescriptions>
        <p class="drawer-note">仅供演示，未连接实际设备。</p>
      </template>
    </SweetDrawer>
  </section>
</template>
<style scoped>
.resources {
  flex: 1; min-width: 0; overflow: auto;
  padding: var(--swt-space-size-24);
  background: var(--swt-color-bg-secondary);
}
.page-heading {
  display: flex; justify-content: space-between; align-items: center;
  margin-bottom: var(--swt-space-size-24);
}
.breadcrumb {
  display: flex; gap: var(--swt-space-size-8); align-items: center;
  color: var(--swt-color-text-secondary); font-size: var(--swt-font-size-small);
}
h1 { font-size: var(--swt-font-size-medium); margin: var(--swt-space-size-12) 0 var(--swt-space-size-8); }
.page-heading p { margin: 0; color: var(--swt-color-text-secondary); font-size: var(--swt-font-size-small); }

.summary-strip {
  display: flex; flex-wrap: wrap; align-items: center;
  background: var(--swt-color-bg-primary);
  border: 1px solid var(--swt-color-dividing-line-primary);
  border-radius: var(--swt-radius-size-big);
  padding: var(--swt-space-size-20) var(--swt-space-size-24);
  gap: var(--swt-space-size-24); margin-bottom: var(--swt-space-size-20);
}
.stat { display: flex; align-items: center; gap: var(--swt-space-size-16); flex: 1; min-width: 160px; }
.stat-icon {
  display: grid; place-items: center;
  width: 44px; height: 44px;
  background: var(--swt-color-overlay-gray1-and-accent-normal-opacity10);
  color: var(--swt-color-accent-text-normal);
  border-radius: var(--swt-radius-size-big);
}
.stat-icon.success {
  background: var(--swt-color-overlay-gray1-and-success-normal-opacity10, rgba(var(--swt-color-success-rgb, 0,168,112), 0.1));
  color: var(--swt-color-success);
}
.stat-icon.alert {
  background: var(--swt-color-overlay-gray1-and-warning-normal-opacity10, rgba(var(--swt-color-warning-rgb, 230,162,60), 0.1));
  color: var(--swt-color-warning);
}
.stat-label { font-size: var(--swt-font-size-small); color: var(--swt-color-text-secondary); }
.stat strong { font-size: var(--swt-font-size-normal2); line-height: 1.2; font-weight: var(--swt-font-weight-bold); }
.unit { font-size: var(--swt-font-size-small); color: var(--swt-color-text-secondary); margin-left: var(--swt-space-size-8); }
.data-source { text-align: right; font-size: var(--swt-font-size-small); color: var(--swt-color-text-extra); }

.table-card {
  background: var(--swt-color-bg-primary);
  border: 1px solid var(--swt-color-dividing-line-primary);
  border-radius: var(--swt-radius-size-big);
  padding: var(--swt-space-size-20) var(--swt-space-size-24);
}
.table-title {
  display: flex; gap: var(--swt-space-size-12); align-items: center;
  margin-bottom: var(--swt-space-size-20);
}
h2 { font-size: var(--swt-font-size-normal1); margin: 0; }
.table-title span { color: var(--swt-color-text-secondary); font-size: var(--swt-font-size-small); }

.filters {
  display: flex; flex-wrap: wrap; align-items: center;
  gap: var(--swt-space-size-12); margin-bottom: var(--swt-space-size-20);
  font-size: var(--swt-font-size-small);
}
.filters label { color: var(--swt-color-text-secondary); white-space: nowrap; }
.query { width: 260px; max-width: 100%; }
.status-select { width: 150px; max-width: 100%; }

.resource-link {
  display: flex; align-items: center; gap: var(--swt-space-size-8);
  border: 0; background: transparent; color: var(--swt-color-accent-text-normal);
  cursor: pointer; font: inherit;
}
.resource-status {
  display: inline-flex; align-items: center; gap: var(--swt-space-size-8);
  color: var(--swt-color-success); font-size: var(--swt-font-size-small);
}
.resource-status i { width: 6px; height: 6px; background: currentColor; border-radius: 50%; }
.resource-status.attention { color: var(--swt-color-warning); }

.table-foot {
  display: flex; justify-content: space-between; align-items: center;
  gap: var(--swt-space-size-16); margin-top: var(--swt-space-size-20);
}
.table-foot > span, .bottom-note { font-size: var(--swt-font-size-small); color: var(--swt-color-text-secondary); }
.bottom-note { text-align: center; margin: var(--swt-space-size-20) 0; }
.drawer-note { color: var(--swt-color-text-secondary); font-size: var(--swt-font-size-small); margin-top: var(--swt-space-size-12); }
</style>
