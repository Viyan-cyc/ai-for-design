<script setup>
import { ref, computed } from 'vue'
import { SweetInput, SweetButton, SweetIcon, SweetTooltip } from '@hw-seq/sweet-ui-base'
const props = defineProps({
  brand: String,
  workspaceName: String,
  menus: { type: Array, default: () => [] },
  tabs: { type: Array, default: () => [] },
  activeMenu: String,
  activeTab: String,
  labels: { type: Object, default: () => ({}) }
})
const emit = defineEmits(['select-menu', 'select-tab', 'close-tab', 'new-tab', 'sessions'])
const expanded = ref(false)
const query = ref('')
const favoritesOnly = ref(false)
const favorites = ref([])
const labels = computed(() => ({
  navigation: '主导航',
  toggle: '展开或收起导航',
  search: '搜索应用',
  allApps: '全部应用',
  myFavorites: '我的收藏',
  empty: '暂无匹配应用',
  tabs: '工作区',
  close: '关闭',
  newTab: '新建工作区',
  sessions: '最近会话',
  collapse: '收起导航',
  expand: '展开导航',
  ...props.labels
}))
const visibleMenus = computed(() =>
  props.menus.filter(m =>
    m.label.toLowerCase().includes(query.value.toLowerCase()) &&
    (!favoritesOnly.value || favorites.value.includes(m.id))
  )
)
function toggleFavorite(id) {
  favorites.value = favorites.value.includes(id)
    ? favorites.value.filter(x => x !== id)
    : [...favorites.value, id]
}
</script>
<template>
  <div class="shell">
    <header class="topnav">
      <SweetButton text :aria-expanded="expanded" :aria-label="labels.toggle" @click="expanded = !expanded">
        <SweetIcon icon-class="sweetui-icon-menu-l" :size="18" />
      </SweetButton>
      <span class="brand">{{ brand }}</span>
      <span v-if="workspaceName" class="product">
        <SweetIcon icon-class="sweetui-icon-dashboard-l" :size="14" />
        {{ workspaceName }}
      </span>
      <div class="top-tools"><slot name="tools" /></div>
    </header>
    <div class="body">
      <aside class="navigation" :class="{ expanded }" :aria-label="labels.navigation">
        <div v-if="expanded" class="nav-search">
          <div class="nav-filters">
            <button type="button" :class="{ selected: !favoritesOnly }" @click="favoritesOnly = false">{{ labels.allApps }}</button>
            <button type="button" :class="{ selected: favoritesOnly }" @click="favoritesOnly = true">{{ labels.myFavorites }}</button>
          </div>
          <SweetInput v-model="query" clearable :placeholder="labels.search" :aria-label="labels.search" size="small" />
        </div>
        <nav class="nav-list">
          <div
            v-for="item in visibleMenus" :key="item.id"
            class="nav-row" :class="{ current: activeMenu === item.id }"
          >
            <SweetTooltip :content="item.label" placement="right" :disabled="expanded">
              <button
                type="button" class="nav-action"
                :aria-label="item.label"
                :aria-current="activeMenu === item.id ? 'page' : undefined"
                @click="emit('select-menu', item.id)"
              >
                <span class="nav-symbol" :class="item.tone">
                  <SweetIcon v-if="item.icon" :icon-class="item.icon" :size="18" />
                  <span v-else class="initial">{{ item.label.slice(0, 1) }}</span>
                </span>
                <span v-if="expanded" class="nav-label">{{ item.label }}</span>
              </button>
            </SweetTooltip>
            <button v-if="expanded" type="button" class="favorite" :aria-label="(favorites.includes(item.id) ? '取消收藏' : '收藏') + item.label" @click="toggleFavorite(item.id)">
              <SweetIcon v-if="expanded" :icon-class="favorites.includes(item.id) ? 'sweetui-icon-favorite-f' : 'sweetui-icon-favorite-l'" :size="14" />
            </button>
          </div>
          <p v-if="expanded && !visibleMenus.length" class="empty">{{ labels.empty }}</p>
        </nav>
        <button type="button" class="collapse-button" :aria-label="expanded ? labels.collapse : labels.expand" @click="expanded = !expanded">
          <SweetIcon :icon-class="expanded ? 'sweetui-icon-arrow-left' : 'sweetui-icon-arrow-right'" :size="16" />
          <span v-if="expanded">{{ labels.collapse }}</span>
        </button>
      </aside>
      <main class="main">
        <div class="tabbar">
          <SweetButton text class="session-toggle" :aria-label="labels.sessions" @click="emit('sessions')">
            <SweetIcon icon-class="sweetui-icon-nav-fold" :size="16" />
          </SweetButton>
          <nav class="tabs" :aria-label="labels.tabs">
            <div
              v-for="tab in tabs" :key="tab.id"
              class="tab" :class="{ active: activeTab === tab.id }"
            >
              <button
                type="button"
                :title="tab.title"
                @click="emit('select-tab', tab.id)"
              >
                <span class="status-dot" :class="tab.status" />
                <span class="tab-title">{{ tab.title }}</span>
              </button>
              <SweetButton
                v-if="tab.closable !== false" text
                :aria-label="labels.close + ' ' + tab.title"
                @click.stop="emit('close-tab', tab.id)"
              >
                <SweetIcon icon-class="sweetui-icon-close" :size="13" />
              </SweetButton>
            </div>
          </nav>
          <SweetButton text :aria-label="labels.newTab" @click="emit('new-tab')">
            <SweetIcon icon-class="sweetui-icon-add-l" :size="17" />
          </SweetButton>
        </div>
        <div class="content"><slot /></div>
        <div v-if="!tabs.length" class="empty-workspace">
          <SweetIcon icon-class="sweetui-icon-add-l" :size="32" />
          <p>暂无工作区</p>
          <SweetButton type="primary" @click="emit('new-tab')">{{ labels.newTab }}</SweetButton>
        </div>
      </main>
    </div>
  </div>
</template>
<style scoped>
.shell {
  height: 100%; min-height: 0; min-width: 0;
  display: flex; flex-direction: column;
  background: var(--swt-color-bg-primary);
  color: var(--swt-color-text-primary);
  --page-line: color-mix(in srgb, var(--swt-color-accent-normal) 10%, var(--swt-color-bg-primary));
}
.topnav {
  height: 48px; display: flex; gap: var(--swt-space-size-12);
  align-items: center; padding: 0 var(--swt-space-size-16) 0 var(--swt-space-size-8);
  border-bottom: 1px solid var(--page-line); flex-shrink: 0;
}
.brand {
  font-size: var(--swt-font-size-normal1);
  font-weight: var(--swt-font-weight-bold);
  color: var(--swt-color-accent-text-normal);
  letter-spacing: .3px;
  white-space: nowrap;
}
.product {
  display: inline-flex; gap: var(--swt-space-size-8); align-items: center;
  border-radius: var(--swt-radius-size-normal);
  background: var(--swt-color-overlay-gray1-and-accent-normal-opacity10);
  padding: var(--swt-space-size-4) var(--swt-space-size-12);
  font-size: var(--swt-font-size-small);
  font-weight: var(--swt-font-weight-bold);
  color: var(--swt-color-accent-text-normal);
  white-space: nowrap;
}
.top-tools { display: flex; align-items: center; margin-left: auto; gap: var(--swt-space-size-12); }

.body { flex: 1; min-height: 0; display: flex; }

.navigation {
  width: 48px; flex-shrink: 0;
  border-right: 1px solid var(--page-line);
  display: flex; flex-direction: column; min-height: 0;
  padding-top: var(--swt-space-size-8);
  transition: width .2s ease;
  overflow: hidden;
}
.navigation.expanded { width: 216px; max-width: 45%; }

.nav-search { padding: var(--swt-space-size-8) var(--swt-space-size-12) var(--swt-space-size-16); }
.nav-filters {
  display: flex; gap: var(--swt-space-size-12); margin-bottom: var(--swt-space-size-12);
  font-size: var(--swt-font-size-small);
}
.nav-filters button {
  font: inherit; cursor: pointer; background: transparent; border: 0;
  color: var(--swt-color-text-secondary);
}
.nav-filters .selected { color: var(--swt-color-accent-text-normal); font-weight: var(--swt-font-weight-bold); }

.nav-list { overflow: auto; flex: 1; }

.nav-row {
  display: flex; align-items: center;
  border-radius: var(--swt-radius-size-normal);
  margin: 0 var(--swt-space-size-4) var(--swt-space-size-8);
}
.nav-row.current { background: var(--swt-color-overlay-gray1-and-accent-normal-opacity10); }

.nav-action {
  height: 40px; flex: 1; display: flex; align-items: center;
  gap: var(--swt-space-size-12); padding: 0 var(--swt-space-size-8);
  min-width: 0; cursor: pointer; font: inherit; color: inherit;
  background: transparent; border: 0; text-align: left;
}
.nav-action:focus-visible { outline: 2px solid var(--swt-color-accent-focus); outline-offset: 2px; }
.nav-symbol {
  width: 24px; height: 24px; max-width: 100%;
  border-radius: var(--swt-radius-size-normal);
  display: grid; place-items: center;
  color: var(--swt-color-accent-text-normal);
  background: var(--swt-color-overlay-gray1-and-accent-normal-opacity10);
  flex-shrink: 0;
}
.nav-symbol.green {
  color: var(--swt-color-success-text-normal);
  background: var(--swt-color-overlay-gray1-and-success-normal-opacity10, color-mix(in srgb, var(--swt-color-success) 12%, var(--swt-color-bg-primary)));
}
.nav-symbol.purple {
  color: var(--swt-color-chart-3, var(--swt-color-accent-text-normal));
  background: var(--swt-color-overlay-gray1-and-chart-3-opacity10, color-mix(in srgb, var(--swt-color-chart-3, var(--swt-color-accent-normal)) 12%, var(--swt-color-bg-primary)));
}
.nav-label {
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
  font-size: var(--swt-font-size-small);
}
.favorite {
  padding: var(--swt-space-size-8); cursor: pointer;
  font: inherit; background: transparent; border: 0;
  color: var(--swt-color-text-extra);
}
.favorite:hover { color: var(--swt-color-accent-text-normal); }

.collapse-button {
  height: 44px; display: flex; align-items: center;
  gap: var(--swt-space-size-12); padding: 0 var(--swt-space-size-16);
  color: var(--swt-color-text-secondary);
  border-top: 1px solid var(--page-line);
  cursor: pointer; font: inherit; background: transparent; border-left: 0; border-right: 0; border-bottom: 0;
}

.empty { padding: var(--swt-space-size-12); color: var(--swt-color-text-secondary); font-size: var(--swt-font-size-small); }
.initial { min-width: 18px; text-align: center; }

.main {
  flex: 1; min-width: 0; min-height: 0;
  display: flex; flex-direction: column;
  position: relative;
}
.tabbar {
  display: flex; align-items: center;
  height: 48px; gap: var(--swt-space-size-8);
  border-bottom: 1px solid var(--page-line);
  padding: 0 var(--swt-space-size-8);
  flex-shrink: 0;
}
.session-toggle {
  border-right: 1px solid var(--page-line);
  border-radius: 0;
}
.tabs {
  display: flex; flex: 1; min-width: 0;
  overflow: auto; gap: var(--swt-space-size-8);
  scrollbar-width: thin;
}
.tab {
  display: flex; align-items: center;
  flex: 0 1 245px; min-width: 150px;
  border-radius: var(--swt-radius-size-normal);
  color: var(--swt-color-text-secondary);
}
.tab > button:first-child {
  flex: 1; display: flex; align-items: center;
  gap: var(--swt-space-size-8); min-width: 0;
  padding: var(--swt-space-size-8) var(--swt-space-size-12);
  cursor: pointer; font: inherit; color: inherit;
  background: transparent; border: 0; text-align: left;
}
.tab.active {
  background: var(--swt-color-overlay-gray1-and-accent-normal-opacity10);
  color: var(--swt-color-accent-text-normal);
}
.tab.active > button:first-child { font-weight: var(--swt-font-weight-bold); }
.tab-title {
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
  font-size: var(--swt-font-size-small);
}
.status-dot {
  width: 8px; height: 8px; border-radius: 50%;
  border: 1.5px solid var(--swt-color-info, var(--swt-color-accent-normal));
  flex-shrink: 0;
}
.status-dot.done {
  border-color: var(--swt-color-success);
  background: var(--swt-color-overlay-gray1-and-success-normal-opacity10, rgba(var(--swt-color-success-rgb, 0,168,112), 0.15));
}
.status-dot.pending { border-color: var(--swt-color-warning); }

.content { flex: 1; min-height: 0; min-width: 0; position: relative; display: flex; overflow: hidden; }

.empty-workspace {
  position: absolute; inset: 0;
  display: flex; flex-direction: column;
  align-items: center; justify-content: center;
  gap: var(--swt-space-size-12);
  color: var(--swt-color-text-secondary);
}
.empty-workspace p { font-size: var(--swt-font-size-normal); margin: 0; }

@media (max-width: 768px) {
  .product { display: none; }
  .navigation { width: 48px; }
}
</style>
