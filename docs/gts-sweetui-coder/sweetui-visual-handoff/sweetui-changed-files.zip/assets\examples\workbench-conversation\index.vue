<script setup>
import { ref, computed, onMounted, onUnmounted } from 'vue'
import { SweetButton, SweetIcon, SweetDialog, SweetAlert } from '@hw-seq/sweet-ui-base'
import WorkbenchShell from './components/foundation/workbench-shell.vue'
import AiWorkspace from './components/ai-workspace.vue'
import ResourceWorkspace from './components/resource-workspace.vue'
import SessionPanel from './components/session-panel.vue'

const mode = ref('ai')
const sessionsOpen = ref(false)
const info = ref('')
const isDark = ref(false)
onMounted(() => { isDark.value = (document.body.getAttribute('theme') || '').includes('dark') })

// watch theme attribute
let themeObserver = null
onMounted(() => {
  themeObserver = new MutationObserver(() => {
    isDark.value = (document.body.getAttribute('theme') || '').includes('dark')
  })
  themeObserver.observe(document.body, { attributes: true, attributeFilter: ['theme'] })
})
onUnmounted(() => { themeObserver?.disconnect() })
const tabs = ref([
  { id: 'mail', title: '邮件应用发送失败排查', status: 'done' },
  { id: 'network', title: '核心交换机链路诊断', status: 'pending' },
  { id: 'storage', title: '存储容量趋势分析', status: 'idle' }
])
const resourceTabs = ref([{ id: 'resources', title: '资源总览', status: 'done', closable: false }])
const activeTab = ref('mail')
const activeResource = ref('resources')
const activeMenu = ref('monitor')
const active = computed(() => tabs.value.find(t => t.id === activeTab.value))
const menus = computed(() => [
  { id: 'monitor', label: mode.value === 'ai' ? '智能监控' : '资源总览', icon: 'sweetui-icon-dashboard-l', tone: 'blue' },
  { id: 'flow', label: mode.value === 'ai' ? '运维流程' : '服务目录', icon: 'sweetui-icon-link-l', tone: 'green' },
  { id: 'jobs', label: '作业中心', icon: 'sweetui-icon-task-list-l', tone: 'blue' },
  { id: 'visual', label: '可视化中心', icon: 'sweetui-icon-indicator-l', tone: 'purple' },
  { id: 'files', label: '知识与文档', icon: 'sweetui-icon-folder-opened-l', tone: 'purple' },
  { id: 'settings', label: '系统设置', icon: 'sweetui-icon-seting-l', tone: 'blue' }
])
function switchMode() { sessionsOpen.value = false; activeMenu.value = 'monitor' }
function toggleTheme() {
  const current = document.body.getAttribute('theme') || ''
  window.setTheme(current.includes('dark') ? 'uDesign2.2-light' : 'uDesign2.2-dark')
}
function closeTab(id) {
  const list = mode.value === 'ai' ? tabs : resourceTabs
  const current = mode.value === 'ai' ? activeTab : activeResource
  const i = list.value.findIndex(t => t.id === id)
  list.value = list.value.filter(t => t.id !== id)
  if (current.value === id) current.value = list.value[Math.max(0, i - 1)]?.id || ''
}
function newTab() {
  const item = { id: `workspace-${Date.now()}`, title: mode.value === 'ai' ? '新排障会话' : '资源查询', status: 'idle' }
  if (mode.value === 'ai') { tabs.value.push(item); activeTab.value = item.id }
  else { resourceTabs.value.push(item); activeResource.value = item.id }
}
function selectMenu(id) {
  activeMenu.value = id
  if (id === 'monitor') return
  const name = menus.value.find(m => m.id === id)?.label
  info.value = `${name}为可配置导航入口。本次聚焦骨架复用，该业务模块尚未接入。`
}
function openSession(item) {
  if (!tabs.value.some(t => t.id === item.id)) tabs.value.push({ ...item, status: 'idle' })
  activeTab.value = item.id
  sessionsOpen.value = false
}
async function fullscreen() {
  try {
    if (document.fullscreenElement) await document.exitFullscreen()
    else await document.documentElement.requestFullscreen()
  } catch { info.value = '当前浏览器不支持页面全屏，请使用浏览器全屏功能。' }
}
</script>
<template>
  <div class="foundation">
    <WorkbenchShell
      :brand="mode === 'ai' ? 'MindOps' : 'CloudOps'"
      :workspace-name="mode === 'ai' ? '智能运维工作台' : '资源管理工作台'"
      :menus="menus"
      :tabs="mode === 'ai' ? tabs : resourceTabs"
      :active-tab="mode === 'ai' ? activeTab : activeResource"
      :active-menu="activeMenu"
      @select-menu="selectMenu"
      @select-tab="mode === 'ai' ? activeTab = $event : activeResource = $event"
      @close-tab="closeTab"
      @new-tab="newTab"
      @sessions="sessionsOpen = !sessionsOpen"
    >
      <template #tools>
        <div class="preview-mode">
          <span>骨架预览</span>
          <select v-model="mode" aria-label="切换示例" @change="switchMode">
            <option value="ai">AI 工作台</option>
            <option value="resources">普通查询页</option>
          </select>
        </div>
        <div class="tool-group">
          <SweetButton text aria-label="打开最近会话" @click="sessionsOpen = !sessionsOpen">
            <SweetIcon icon-class="sweetui-icon-manage-tasks-l" :size="17" />
          </SweetButton>
          <SweetButton text aria-label="查看通知" @click="info = '当前为离线预览，没有新的业务通知。'">
            <SweetIcon icon-class="sweetui-icon-message-l" :size="17" />
          </SweetButton>
          <SweetButton text aria-label="全屏预览" @click="fullscreen">
            <SweetIcon icon-class="sweetui-icon-full-screen-l" :size="17" />
          </SweetButton>
          <SweetButton text aria-label="切换深浅主题" @click="toggleTheme">
            <SweetIcon :icon-class="isDark ? 'sweetui-icon-skin-peeler-l' : 'sweetui-icon-skin-peeler-l'" :size="17" />
          </SweetButton>
          <span class="avatar">运</span>
        </div>
      </template>

      <SessionPanel
        v-if="sessionsOpen"
        :business="mode === 'resources'"
        @close="sessionsOpen = false"
        @open="openSession"
        @new="newTab(); sessionsOpen = false"
      />

      <template v-if="mode === 'ai'">
        <template v-for="tab in tabs" :key="tab.id">
          <AiWorkspace v-show="activeTab === tab.id" :session="tab" />
        </template>
        <div v-if="!active" class="empty-state">
          <SweetIcon icon-class="sweetui-icon-message-l" :size="40" />
          <p>开始一个新的工作区</p>
          <SweetButton type="primary" @click="newTab">新建会话</SweetButton>
        </div>
      </template>
      <template v-else>
        <template v-for="tab in resourceTabs" :key="tab.id">
          <ResourceWorkspace v-show="activeResource === tab.id" />
        </template>
      </template>
    </WorkbenchShell>

    <SweetDialog :model-value="!!info" title="预览说明" width="440" draggable :close-on-click-modal="false" @update:model-value="info = ''">
      <p>{{ info }}</p>
      <template #footer>
        <SweetButton type="primary" @click="info = ''">知道了</SweetButton>
      </template>
    </SweetDialog>
  </div>
</template>
<style scoped>
.foundation {
  height: 100vh; overflow: hidden;
  font-size: var(--swt-font-size-normal);
  line-height: var(--swt-font-line-height-normal);
  color: var(--swt-color-text-primary);
}
.preview-mode {
  display: flex; gap: var(--swt-space-size-8); align-items: center;
  font-size: var(--swt-font-size-small); color: var(--swt-color-text-secondary);
  border-right: 1px solid var(--swt-color-dividing-line-primary);
  padding-right: var(--swt-space-size-16);
}
.preview-mode select {
  font: inherit; color: var(--swt-color-accent-text-normal); border: 0;
  background: var(--swt-color-bg-primary); cursor: pointer;
  outline-color: var(--swt-color-accent-normal);
}
.tool-group { display: flex; align-items: center; gap: var(--swt-space-size-12); }
.avatar {
  width: 28px; height: 28px; max-width: 100%;
  display: grid; place-items: center; border-radius: 50%;
  color: var(--swt-color-text-inverse);
  background: var(--swt-color-accent-normal);
  font-size: var(--swt-font-size-small);
  border: 2px solid var(--swt-color-overlay-gray1-and-accent-normal-opacity10);
}
.empty-state {
  flex: 1; display: flex; flex-direction: column;
  align-items: center; justify-content: center;
  gap: var(--swt-space-size-12); color: var(--swt-color-text-secondary);
}
.empty-state p { font-size: var(--swt-font-size-normal); margin: 0; }

@media (max-width: 992px) {
  .preview-mode > span { display: none; }
  .tool-group { gap: var(--swt-space-size-4); }
}
</style>
