<script setup>
import { ref, onMounted, computed } from 'vue'
import { SweetButton, SweetInput, SweetIcon } from '@hw-seq/sweet-ui-base'
import { getSessions } from '../api/foundation.js'
defineProps({ business: Boolean })
defineEmits(['close', 'open', 'new'])
const sessions = ref([])
const query = ref('')
const error = ref('')
const filtered = computed(() => sessions.value.filter(x => x.title.includes(query.value)))
async function load() {
  try { sessions.value = await getSessions(); error.value = '' }
  catch { error.value = '会话加载失败' }
}
onMounted(load)
</script>
<template>
  <aside class="panel">
    <header>
      <strong>{{ business ? '工作区入口' : '最近会话' }}</strong>
      <SweetButton text :aria-label="'关闭'" @click="$emit('close')">
        <SweetIcon icon-class="sweetui-icon-close" :size="14" />
      </SweetButton>
    </header>
    <div class="controls">
      <SweetButton type="primary" size="small" @click="$emit('new')">
        <SweetIcon icon-class="sweetui-icon-add-l" :size="14" />
        {{ business ? '新建查询页' : '新建会话' }}
      </SweetButton>
      <SweetInput v-if="!business" v-model="query" clearable placeholder="搜索会话" aria-label="搜索会话" size="small" />
    </div>
    <div v-if="error" class="panel-error">
      {{ error }}
      <SweetButton size="small" @click="load">重试</SweetButton>
    </div>
    <template v-if="!business">
      <button
        v-for="item in filtered" :key="item.id"
        type="button" class="session-item"
        @click="$emit('open', item)"
      >
        <SweetIcon icon-class="sweetui-icon-message-l" :size="18" />
        <span class="session-body">
          <strong>{{ item.title }}</strong>
          <small>{{ item.time }} · {{ item.status }}</small>
        </span>
      </button>
      <p v-if="!filtered.length" class="empty">暂无匹配会话</p>
    </template>
    <p class="foot">{{ business ? '同一骨架，可装配不同业务内容。' : '演示会话 · 不连接生产数据' }}</p>
  </aside>
</template>
<style scoped>
.panel {
  position: absolute; left: 0; top: 0; bottom: 0;
  width: 336px; max-width: 100%; z-index: 20;
  background: var(--swt-color-bg-secondary);
  border-right: 1px solid var(--swt-color-dividing-line-primary);
  box-shadow: var(--swt-shadow1, 0 2px 8px rgba(0,0,0,.12));
  padding: var(--swt-space-size-20); box-sizing: border-box; overflow: auto;
}
.panel header {
  display: flex; justify-content: space-between; align-items: center;
  margin-bottom: var(--swt-space-size-20);
}
.panel header strong { font-size: var(--swt-font-size-normal); }
.controls {
  display: flex; flex-direction: column; gap: var(--swt-space-size-12);
  margin-bottom: var(--swt-space-size-20);
}
.session-item {
  display: flex; gap: var(--swt-space-size-12); text-align: left;
  width: 100%; padding: var(--swt-space-size-16) var(--swt-space-size-8);
  background: transparent; color: var(--swt-color-text-primary); border: 0;
  border-bottom: 1px solid var(--swt-color-dividing-line-primary);
  cursor: pointer; font: inherit;
}
.session-item:hover { background: var(--swt-color-overlay-gray1-and-accent-normal-opacity10); }
.session-item .sweeticon { color: var(--swt-color-accent-text-normal); }
.session-body { flex: 1; min-width: 0; }
.session-body strong { font-size: var(--swt-font-size-small); display: block; }
.session-body small { display: block; color: var(--swt-color-text-secondary); margin-top: var(--swt-space-size-4); }
.panel-error { color: var(--swt-color-danger-text-normal); font-size: var(--swt-font-size-small); margin-bottom: var(--swt-space-size-12); }
.empty { color: var(--swt-color-text-secondary); font-size: var(--swt-font-size-small); padding: var(--swt-space-size-12); }
.foot {
  font-size: var(--swt-font-size-small); color: var(--swt-color-text-secondary);
  margin-top: var(--swt-space-size-24);
}
</style>
